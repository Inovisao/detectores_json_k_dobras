
Ovos - v1 2021-04-27 5:52pm
==============================

This dataset was exported via roboflow.ai on April 27, 2021 at 9:52 PM GMT

It includes 8 images.
Ovos are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


